
clear all
close all



ns = 2^10; % number of samples
t = linspace(0,1,ns); % signal of 1s (0 to 1) sampled ns-times
f = linspace(-ns/2,ns/2 -1,ns); % frequencies
in = exp(2 *pi* 1i*(ns/2^2)*t).*((0/8<=t)&(t<1/8))+...
     exp(2 *pi* 1i*(ns/2^3)*t).*((1/8<=t)&(t<2/8))+ ...
     exp(2 *pi* 1i*(ns/2^4)*t).*((2/8<=t)&(t<3/8))+...
     exp(2 *pi* 1i*(ns/2^5)*t).*((3/8<=t)&(t<4/8))+...
     exp(2 *pi* 1i*(ns/2^6)*t).*((4/8<=t)&(t<5/8))+...
     exp(2 *pi* 1i*(-ns/2^2)*t).*((5/8<=t)&(t<6/8))+ ...
     exp(2 *pi* 1i*(-ns/2^3)*t).*((6/8<=t)&(t<7/8))+...
     exp(2 *pi* 1i*(-ns/2^4)*t).*((7/8<=t)&(t<8/8));
     
if (sum(mod(log2(size(in)), 1)) == 0)
else
    error('ERROR: STransfomrs works with signal with a 2^k size.')
end

fftIn = ST.fourier(in);
dostIn = ST.dost(in);
recdostIn = ST.idost(ST.dost(in));


readableDostIn = ST.rearrangeDost(dostIn);

figure
subplot(3, 1, 1)
plot(t, real(in))
title('input signal, real part')
xlabel('time')
ylabel('amplitude')
axis tight
subplot(3, 1, 2)
plot(f,abs(fftIn))
title('normalized and centered fft (abs)')
xlabel('frequency')
ylabel('magnitude')
axis tight
subplot(3, 1, 3)
imagesc(t,f,abs(readableDostIn))
title('dost representation')
xlabel('time')
ylabel('frequency')
axis tight

in = real(in);  % real signal
f = linspace(0,ns/2 -1,ns); % real frequencies

dctIn = dct(in);
dcstIn = ST.dcst(in);
recdcstIn = ST.idcst(ST.dcst(in));
% to simplify the interpratation of the dcst coefficients we rearrange them
% in the phase space.
readableDcstIn = ST.rearrangeDcst(dcstIn);

figure
subplot(3, 1, 1)
plot(t, in)
title('input signal')
xlabel('time')
ylabel('magnitude')
axis tight
subplot(3, 1, 2)
plot(f,dctIn)
title('dct')
xlabel('frequency')
ylabel('magnitude')
axis tight
subplot(3, 1, 3)
imagesc(t,f,readableDcstIn)
title('dcst')
xlabel('time')
ylabel('frequency')
axis tight
%
% -------------------------------------------------------------------------

load tartan
in2d = X;


 in2d = double(imread('lena512.bmp'));

if (sum(mod(log2(size(in2d)), 1)) == 0)
else
    error('ERROR: STransfomrs works with signal with a 2^k size.')
end

fft2In2d = ST.fourier2(in2d);
dost2In2d = ST.dost2(in2d);
recdostIn2d = ST.idost2(ST.dost2(in2d));

figure
subplot(1, 3, 1)
imagesc(in2d)
title('input signal')
xlabel('x_1')
ylabel('x_2')
axis equal tight
set(gca, 'XTickLabel', '', 'YTickLabel', '')
subplot(1, 3, 2)
imagesc(log(abs(fft2In2d) + 1))
title('normalized and centered fft2')
xlabel('\xi_1')
ylabel('\xi_2')
set(gca, 'XTickLabel', '', 'YTickLabel', '')
axis equal tight
subplot(1, 3, 3)
imagesc(log(abs(dost2In2d) + 1))
title('dost2 ')
xlabel('\xi_1')
ylabel('\xi_2')
set(gca, 'XTickLabel', '', 'YTickLabel', '')
axis equal tight
colormap gray

dct2In2d = dct2(in2d);
dcst2In2d = ST.dcst2(in2d);
recdcstIn2d = ST.idcst2(ST.dcst2(in2d));

figure
subplot(1, 3, 1)
imagesc(in2d)
title('input signal')
xlabel('x_1')
ylabel('x_2')
set(gca, 'XTickLabel', '', 'YTickLabel', '')
axis equal tight
subplot(1, 3, 2)
imagesc(log(abs(dct2In2d + 1)))
title('dct2')
xlabel('\xi_1')
ylabel('\xi_2')
set(gca, 'XTickLabel', '', 'YTickLabel', '')
axis equal tight
subplot(1, 3, 3)
imagesc(log(abs(dcst2In2d + 1)))
title('dcst2')
xlabel('\xi_1')
ylabel('\xi_2')
set(gca, 'XTickLabel', '', 'YTickLabel', '')
axis equal tight
colormap gray

