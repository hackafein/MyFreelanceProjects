
classdef ST
    methods(Static = true, Access = public)
        
        % normalized and centered fft
        function out = fourier(in)
            switch isvector(in)
                case true
                    out = (1 ./ sqrt(length(in))) .* fftshift(fft(ifftshift(in)));
                otherwise
                    out = (1 ./ sqrt(size(in, 1))) .* fftshift(fft(ifftshift(in, 1), [], 1), 1);
            end
        end
        
        % normalized and centered ifft
        function out = ifourier(in)
            switch isvector(in)
                case true
                    out = sqrt(length(in)) .* fftshift(ifft(ifftshift(in)));
                otherwise
                    out = sqrt(size(in, 1)) .* fftshift(ifft(ifftshift(in, 1), [], 1), 1);
            end
        end
        
        % fourier2 transform
        function out = fourier2(in)
            switch (isvector(in))
                case true
                    out = ST.fourier(in);
                otherwise
                    out = ST.fourier(ST.fourier(in).').';
            end
        end
        
        % ifourier2 transform
        function out = ifourier2(in)
            switch (isvector(in))
                case true
                    out = ST.ifourier(in);
                otherwise
                    out = ST.ifourier(ST.ifourier(in).').';
            end
        end
        
        % DOST - discrete orthonormal Stockwell transforms
        % dost transform
        function out = dost(in)
            switch(isvector(in))
                case true
                    out = ST.fourier(in);
                    D = length(in);
                    bw = ST.dostbw(D);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            out(k : k + ii - 1) = ST.ifourier(out(k : k + ii - 1));
                            k = k + ii;
                        end
                    end
                otherwise
                    out = ST.fourier(in);
                    M = size(in, 1);
                    bw = ST.dostbw(M);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            out(k : k + ii - 1, :) = ST.ifourier(out(k:k + ii - 1, :));
                            k = k + ii;
                        end
                    end
            end
        end
        
        %idost transform
        function out = idost(in)
            switch (isvector(in))
                case true
                    out = in;
                    D = length(in);
                    bw = ST.dostbw(D);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            out(k : k + ii - 1) = ST.fourier(out(k : k + ii - 1));
                            k = k + ii;
                        end
                    end
                    out = ST.ifourier(out);
                otherwise
                    out = in;
                    M = size(in, 1);
                    bw = ST.dostbw(M);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            out(k : k + ii - 1, :) = ST.fourier(out(k : k + ii - 1, :));
                            k = k + ii;
                        end
                    end
                    out = ST.ifourier(out);
            end
            
        end
        
        % dost2 transform
        function out = dost2(in)
            switch (isvector(in))
                case true
                    out = ST.dost(in);
                otherwise
                    out = ST.dost(ST.dost(in).').';
            end
        end
        
        % idost2 transform
        function out = idost2(in)
            switch (isvector(in))
                case true
                    out = ST.idost(in);
                otherwise
                    out = ST.idost(ST.idost(in).').';
            end
        end
        
        % DCST - discrete cosine Stockwell transforms
        % dcst transform
        function out = dcst(in)
            switch(isvector(in))
                case true
                    out = dct(in);
                    D = length(in);
                    bw = ST.dcstbw(D);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            out(k : k + ii - 1) = idct(out(k : k + ii - 1));
                            k = k + ii;
                        end
                    end
                otherwise
                    out = dct(in);
                    M = size(in, 1);
                    bw = ST.dcstbw(M);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            
                            out(k : k + ii - 1, :) = idct(out(k:k + ii - 1, :));
                            k = k + ii;
                        end
                    end
            end
        end
        
        %idcst transform
        function out = idcst(in)
            switch (isvector(in))
                case true
                    out = in;
                    D = length(in);
                    bw = ST.dcstbw(D);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            out(k : k + ii - 1) = dct(out(k : k + ii - 1));
                            k = k + ii;
                        end
                    end
                    out = idct(out);
                otherwise
                    out = in;
                    M = size(in, 1);
                    bw = ST.dcstbw(M);
                    k = 1;
                    for ii = bw
                        if ii == 1
                            k = k + ii;
                        else
                            out(k : k + ii - 1, :) = dct(out(k : k + ii - 1, :));
                            k = k + ii;
                        end
                    end
                    out = idct(out);
            end
            
        end
        
        % dcst2 transform
        function out = dcst2(in)
            switch (isvector(in))
                case true
                    out = ST.dcst(in);
                otherwise
                    out = ST.dcst(ST.dcst(in).').';
            end
        end
        
        % idcst2 transform
        function out = idcst2(in)
            switch (isvector(in))
                case true
                    out = ST.idcst(in);
                otherwise
                    out = ST.idcst(ST.idcst(in).').';
            end
        end
        
        % rearrangeDost
        % the dost coefficients have a meaning as time-frequency energy
        % content. This function rearrange the coefficients in a matrix form
        % which encodes these information
        function out = rearrangeDost(in)
            switch(isvector(in))
                case true
                    D = length(in);
                    bw = ST.dostbw(D);
                    tbw = D ./ bw;
                    out = zeros(D, D);
                    count = 1;
                    for hh = 1:length(bw)
                        for kk = 1: bw(hh)
                            ii = D + 1 - sum(bw(1:hh));
                            jj = tbw(hh) * (kk - 1) + 1;
                            tmp = repmat(count, bw(hh), tbw(hh));
                            out(ii:ii + size(tmp, 1) - 1, jj:jj + size(tmp, 2) - 1) = tmp;
                            count = count + 1;
                        end
                    end
                    out = in(out);
                otherwise
                    error('ERROR: This method is intended to work with 1d vectors');
            end
        end
        

        function out = rearrangeDcst(in)
            switch (isvector(in))
                case true
                    D = length(in);
                    bw = ST.dcstbw(D);
                    tbw = D ./ bw;
                    out = zeros(D, D);
                    count = 1;
                    for hh = 1:length(bw)
                        for kk = 1: bw(hh)
                            ii = D + 1 - sum(bw(1:hh));
                            jj = tbw(hh) * (kk - 1) + 1;
                            tmp = repmat(count, bw(hh), tbw(hh));
                            out(ii:ii + size(tmp, 1) - 1, jj:jj + size(tmp, 2) - 1) = tmp;
                            count = count + 1;
                        end
                    end
                    out = in(out);
                otherwise
                    error('ERROR: This method is intended to work with 1d vectors');
            end
        end
    end
    
    methods(Static = true, Access = private)

        function out = dostbw(in)
            out = 2 .^ ([0, log2(in) - 2: - 1:0, 0, 0:log2(in) - 2]);
        end
        

        function out = dcstbw(in)
            out = 2 .^ ([0, 0:log2(in) - 1]);
        end
        
    end
    
end
